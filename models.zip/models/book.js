const mongoose = require('mongoose');

const Book = new mongoose.Schema({
  ISBN: { type: Number, required: true },
  name: String,
  price: Number,
  isInStock: String,
  edition: Number,
  printDate: Date,
});

module.exports = mongoose.model('Book', Book);
